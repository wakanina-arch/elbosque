# AppElBosque

¡Bienvenido a AppElBosque!

Esta es una aplicación en desarrollo para gestionar y ofrecer servicios locales (restaurantes, peluquerías, etc.) en la comunidad El Bosque.

## ¿Cómo probar la app?

1. **Haz clic en el botón verde "Code" y luego en "Download ZIP" para descargar el proyecto a tu computadora.**
2. **Descomprime el archivo ZIP en una carpeta.**
3. **Envíame un mensaje o avísame cuando lo tengas listo para que te ayude a abrirlo y probarlo.**

---

> Si tienes dudas o necesitas reponer productos, solo avísame y te guío paso a paso. No necesitas saber de programación.

---

**Contacto técnico:** Edgar Jara Gomez

---

¡Gracias por tu colaboración y feedback!
