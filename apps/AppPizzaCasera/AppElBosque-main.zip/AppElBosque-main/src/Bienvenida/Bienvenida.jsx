import React from "react";
import "./Bienvenida.css";

export default function Bienvenida() {
  return (
    <div className="bienvenida-container">
      <h1>¡Bienvenido a Pizza Casera!</h1>
      {/* Aquí puedes agregar imágenes, textos y estilos personalizados */}
    </div>
  );
}
