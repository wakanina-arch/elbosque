import React from "react";
import "../Ensaladas/Ensaladas.css";

export default function Ensaladas() {
  return (
    <div className="ensaladas-container">
      <h2>Selecciona tu Ensalada</h2>
      {/* Aquí puedes mostrar las ensaladas disponibles */}
    </div>
  );
}
